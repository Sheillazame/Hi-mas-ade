// Function to show the pelukan virtual message
function showMessage() {
    document.getElementById('message').classList.remove('hidden');
    document.getElementById('semangatButton').classList.add('hidden');
}

// Function to show more messages
function showMoreMessages() {
    document.getElementById('extraMessages').classList.remove('hidden');
    document.getElementById('moreMessages').classList.add('hidden');
}